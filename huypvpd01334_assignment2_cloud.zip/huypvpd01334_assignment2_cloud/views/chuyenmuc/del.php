<div class="row">
    <div class="col-sm-9">
    <div class="panel panel-default">
    <div class="panel-heading"><a href="chuyenmuc.php">Quản Lý Chuyên Mục</a> >> Xóa Chuyên Mục</div> </div>
<form class="login-form" role="form" action="chuyenmuc.php?act=del&id=<?php echo $id; ?>" method="post">
    <button class="btn btn-danger" type="submit" name="ok">Xóa</button></form>
    </div>
</div>