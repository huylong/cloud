-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2016 at 12:38 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--
CREATE DATABASE IF NOT EXISTS `demo` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `demo`;

-- --------------------------------------------------------

--
-- Table structure for table `chuyenmuc`
--

CREATE TABLE `chuyenmuc` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `mota` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `chuyenmuc`
--

TRUNCATE TABLE `chuyenmuc`;
--
-- Dumping data for table `chuyenmuc`
--

INSERT INTO `chuyenmuc` (`id`, `name`, `mota`) VALUES
(1, 'Áo Sơ Mi Nam', 'Áo sơ mi nam 2016 giá rẻ, chất lượng tốt từ nhiều shop uy tín tại SENDO.VN - Giao hàng tận nơi trên toàn quốc - Sàn TMĐT chính thức của tập đoàn FPT.'),
(2, 'Quần Jean Nam', 'Quần jean nam 2016 giá rẻ, chất lượng tốt từ nhiều shop uy tín tại SENDO.VN - Giao hàng tận nơi trên toàn quốc - Sàn TMĐT chính thức của tập đoàn FPT.'),
(4, 'Áo Sơ MI Nữ', 'Áo sơ mi nữ 2016 giá rẻ, chất lượng tốt từ nhiều shop uy tín tại SENDO.VN - Giao hàng tận nơi trên toàn quốc - Sàn TMĐT chính thức của tập đoàn FPT.'),
(5, 'Áo Thun Nữ', 'Áo thun nữ có tay 2016 giá rẻ, chất lượng tốt từ nhiều shop uy tín tại SENDO.VN - Giao hàng tận nơi trên toàn quốc - Sàn TMĐT chính thức của tập đoàn FPT.');

-- --------------------------------------------------------

--
-- Table structure for table `hoadon`
--

CREATE TABLE `hoadon` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `diachi` varchar(300) NOT NULL,
  `email` varchar(80) NOT NULL,
  `sdt` varchar(20) NOT NULL,
  `time` int(11) NOT NULL,
  `check` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `hoadon`
--

TRUNCATE TABLE `hoadon`;
--
-- Dumping data for table `hoadon`
--

INSERT INTO `hoadon` (`id`, `name`, `diachi`, `email`, `sdt`, `time`, `check`) VALUES
(1, 'Phạm Văn Huy', '138 Nguyễn Thị Thập ĐN', 'huypvpd01334@fpt.edu.vn', '0978246453', 1456991142, 'Đã Thanh Toán'),
(2, 'Lisa Dorman', '548 Hà Tây', 'huyad1102@gmail.vn', '0123458788', 1456992472, 'Đang Thanh Toán'),
(3, 'Lisa Dorman', '548 Hà Tây', 'huyad1102@gmail.vn', '0123458788', 1457027956, 'Chưa Thanh Toán'),
(4, 'Nguyễn Hoài Nam', '123 Hùng Vương, Đà Nẵng', 'nam@gmail.com', '01234589654', 1457101331, 'Chưa Thanh Toán'),
(5, 'Lê Thì Mai', '22 Hùng vương, Hà Nội', 'mainobi@gmail.com', '0978548268', 1457260541, 'Chưa Thanh Toán'),
(6, 'Nguyễn Quốc Bảo', '135 Điện Biên Phủ, Đà Nẵng', 'thienhavosong@gmail.com', '01224589478', 1457260595, 'Chưa Thanh Toán'),
(7, 'Bùi Anh Tuấn', '487 Nguyễn Tri Phương, Đà Nẵng', 'tuanit@yahoo.com', '0903487478', 1457260695, 'Đã Thanh Toán'),
(8, 'Lê Hoài Nam', '208 Nguyễn Thị Thập ĐN', 'nampd4585@fpt.edu.vn', '03289598987', 1471429568, 'Chưa Thanh Toán'),
(9, 'Võ Thị Mỹ', '22 Ngũ Hành Sơn', 'myhaitay@gmail.com', '0978245632', 1471429632, 'Chưa Thanh Toán'),
(10, 'test', '22 Nguyễn Trãi, Tây Hồ', 'test@gmail.com', '0123487995', 1471429822, 'Chưa Thanh Toán');

-- --------------------------------------------------------

--
-- Table structure for table `hoadon_chitiet`
--

CREATE TABLE `hoadon_chitiet` (
  `id` int(11) NOT NULL,
  `mahd` int(11) NOT NULL,
  `masp` int(11) NOT NULL,
  `soluong` int(11) NOT NULL,
  `gia` varchar(30) NOT NULL,
  `tensp` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `hoadon_chitiet`
--

TRUNCATE TABLE `hoadon_chitiet`;
--
-- Dumping data for table `hoadon_chitiet`
--

INSERT INTO `hoadon_chitiet` (`id`, `mahd`, `masp`, `soluong`, `gia`, `tensp`) VALUES
(1, 1, 6, 6, '155000', 'Quần Thun Nam Thể Thao Hàn Quốc - NH19'),
(2, 2, 2, 5, '209000', 'Áo Sơ Mi Nam Tay Dài Phối Màu - HE120 - SMA017'),
(3, 2, 4, 4, '175000', 'Áo Sơ Mi Nữ Họa Tiết Sao Biển Thời Trang - SG463'),
(4, 2, 5, 2, '115000', 'Áo Thun Nữ Cài Nút Cá Tính - TD03'),
(5, 3, 5, 5, '115000', 'Áo Thun Nữ Cài Nút Cá Tính - TD03'),
(6, 4, 4, 4, '175000', 'Áo Sơ Mi Nữ Họa Tiết Sao Biển Thời Trang - SG463'),
(7, 5, 1, 4, '179000', 'ÁO SƠ MI NỮ FORM DÀI CÁ TÍNH - DR99 - SM2021'),
(8, 5, 2, 2, '209000', 'Áo Sơ Mi Nam Tay Dài Phối Màu - HE120 - SMA017'),
(9, 5, 4, 1, '175000', 'Áo Sơ Mi Nữ Họa Tiết Sao Biển Thời Trang - SG463'),
(10, 6, 3, 3, '195000', 'Áo Sơ Mi Nam Tay Dài Phối Viền Màu Thời Trang'),
(11, 7, 1, 5, '179000', 'ÁO SƠ MI NỮ FORM DÀI CÁ TÍNH - DR99 - SM2021'),
(12, 7, 3, 1, '195000', 'Áo Sơ Mi Nam Tay Dài Phối Viền Màu Thời Trang'),
(13, 7, 4, 3, '175000', 'Áo Sơ Mi Nữ Họa Tiết Sao Biển Thời Trang - SG463'),
(14, 7, 5, 4, '115000', 'Áo Thun Nữ Cài Nút Cá Tính - TD03'),
(15, 8, 2, 2, '209000', 'Áo Sơ Mi Nam Tay Dài Phối Màu - HE120'),
(16, 9, 10, 10, '125000', 'Áo Thun Nữ Tay Dài Phối Sọc Cá Tính'),
(17, 10, 8, 10, '210000', 'Quần Short Kaki Nam Phối Nắp Túi Thời Trang'),
(18, 10, 10, 8, '125000', 'Áo Thun Nữ Tay Dài Phối Sọc Cá Tính'),
(19, 10, 11, 11, '195000', 'Áo Sơ Mi Trắng Form Dài Thời Trang');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `id` int(11) NOT NULL,
  `name` varchar(300) NOT NULL,
  `text` text NOT NULL,
  `chuyenmuc` varchar(11) NOT NULL,
  `img` varchar(255) NOT NULL,
  `gia` varchar(100) NOT NULL,
  `time` int(11) NOT NULL,
  `views` int(11) NOT NULL DEFAULT '0',
  `gianhap` varchar(100) NOT NULL,
  `soluong` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `sanpham`
--

TRUNCATE TABLE `sanpham`;
--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`id`, `name`, `text`, `chuyenmuc`, `img`, `gia`, `time`, `views`, `gianhap`, `soluong`) VALUES
(1, 'ÁO SƠ MI NỮ FORM DÀI CÁ TÍNH - DR99 ', 'Áo cổ bẻ, tay lỡ thời trang, thiết kế vạt sau dài hơn vạt trước, phối nút phá cách tôn nét trẻ trung, sành điệu cho bạn nữ.\r\nTông màu tươi sáng, form chuẩn vừa người, dễ mix cùng trang phục khác.\r\nÁo  tạo cho người mặc dáng vẻ nhẹ nhàng, thanh thoát và không kém phần cá tính.\r\nChất liệu: kate lụa\r\nSize: M, L.', '1', 'img/AO-SO-MI-NU-FORM-DAI-CA-TINH---DR99---SM2021.jpg', '179000', 1457770481, 4, '160000', 200),
(2, 'Áo Sơ Mi Nam Tay Dài Phối Màu - HE120 ', 'Áo sơ mi nam phối màu trẻ trung, phá cách là sự lựa chọn vô cùng hoàn hảo cho bạn trai.\r\nThiết kế cổ bẻ, tay dài, thân áo phối màu trang nhã, tinh tế.\r\nMang lại sự tự tin, nét trẻ trung, năng động cho phái mạnh.\r\nMàu sắc trang nhã, dễ dàng mix cùng các trang phục khác.\r\nChất liệu: Kaki thun có độ co dãn, thoải mái.\r\nThể hiện vẻ năng động, trẻ trung của phái mạnh, đường cắt may khéo léo.\r\nMàu sắc	Chất liệu	Size	Dài áo	Rộng vai	Dài tay	Vòng ngực	Phù hợp (kg)', '1', 'img/Ao-So-Mi-Nam-Tay-Dai-Phoi-Mau---HE120---SMA017.jpg', '209000', 1457674629, 2, '190000', 210),
(3, 'Áo Sơ Mi Nam Tay Dài Phối Viền Màu Thời Trang', 'Áo sơ mi nam kiểu dáng trẻ trung, nam tính, phối viền màu ấn tượng cho bạn vẻ ngoài tự tin, nổi bật khi đi làm, đi học, đi chơi,...\r\nKiểu dáng thời trang, form dáng chuẩn phối viền màu tinh tế tôn nét khỏe khoắn, nam tính cho phái mạnh.\r\nThiết kế cổ bẻ, tay dài, đường chỉ may tỉ mỉ, tinh tế cùng tông màu trang nhã cho bạn nhiều sự lựa chọn khi kết hợp cùng các trang phục khác.\r\nMang lại vẻ nam tính, trẻ trung và không kém phần thanh lịch cho bạn trai.\r\nChất liệu: Kate.\r\nSize: L, XL.', '1', 'img/Ao-So-Mi-Nam-Tay-Dai-Phoi-Vien-Mau-Thoi-Trang.jpg', '195000', 1457673440, 3, '185000', 100),
(4, 'Áo Sơ Mi Nữ Họa Tiết Sao Biển Thời Trang - SG463', 'Áo sơ mi nữ họa tiết sao biển độc đáo, lạ mắt, form áo chuẩn, vừa người mang đến vẻ nữ tính, thanh lịch cho bạn gái.\r\nÁo sơ mi nữ thiết kế cổ tim, tay áo dài, in họa tiết sao biển nổi bật, ấn tượng cho bạn vẻ ngoài tự tin, thanh lịch.\r\nMàu sắc trang nhã, form dáng thời trang cho bạn dễ dàng kết hợp cùng các trang phục khác như quần âu, chân váy,...\r\nThiết kế cách tân cho bạn tự tin thể hiện phong cách ăn mặc tinh tế, thời trang.\r\nChất liệu:Cát hàn.\r\nThích hợp với bạn gái dưới 53Kg (tùy chiều cao).', '4', 'img/Ao-So-Mi-Nu-Hoa-Tiet-Sao-Bien-Thoi-Trang---SG463.jpg', '175000', 1456989899, 2, '160000', 300),
(5, 'Áo Thun Nữ Cài Nút Cá Tính - TD03', 'Áo thun nữ cài nút với thiết kế đơn giản, cài nút tinh tế dễ biến tấu với nhiều kiểu trang phục và phụ kiện mang đến phong cách thời trang sành điệu.\r\nForm áo body tạo nét khỏe khoắn và năng động cho trang phục thêm phần cuốn hút.\r\nÁo thun cổ tròn cài nút là loại trang phục đơn giản, dễ mặc và dễ phối trang phục.\r\nChất liệu thun mềm mại, thoáng mát, con giãn, thấm hút mồ hôi tốt.\r\nThích hợp bạn gái dưới 50kg.', '5', 'img/Ao-Thun-Nu-Cai-Nut-Ca-Tinh---TD03.png', '115000', 1456989987, 15, '100000', 120),
(6, 'Quần Thun Nam Thể Thao Hàn Quốc - NH19', 'Thiết kế lưng thun, kèm với dây rút tạo cảm giác thoải mái khi mặc.\r\nEo thun và rút dây giúp bạn nam dễ dàng điều chỉnh.\r\nThích hợp mặc ở nhà hay đi tập thể thao, đi biển...\r\nDễ dàng kết hợp với các mẫu áo thun.\r\nChất liệu: thun da cá thoáng mát, thấm hút mồ hôi tốt, dễ dàng giặt ủi.\r\nPhù hợp với bạn dưới 65kg (tùy chiều cao)', '2', 'img/Quan-Thun-Nam-The-Thao-Han-Quoc---NH19.jpg', '155000', 1456990123, 6, '145000', 80),
(7, 'Quần âu Kaki nam thời trang - CRK06', 'Kết hợp dễ dàng với nhiều kiểu áo thun, sơ mi, giày lười hoặc giày thể thao thể hiện vẻ nam tính và sánh điệu\r\nThiết kế form suông tôn dáng, đường may tinh tế, tỉ mỉ giúp các chàng trai thể hiện phong thái nam tính.\r\nChất liệu kaki thông thoáng, tạo cảm giác thoải mái khi vận động.\r\nDễ dàng kết hợp với các mẫu sơ mi, áo thun ...\r\nSize: 29 - 30 - 31 - 32 - 33', '2', 'img/Quan-au-Kaki-nam-thoi-trang---CRK06.jpg', '201000', 1471428975, 1, '195000', 200),
(8, 'Quần Short Kaki Nam Phối Nắp Túi Thời Trang', 'Quần short nam kiểu dáng trẻ trung, năng động mang lại nét khỏe khắn, nam tính cho phái mạnh.\r\nQuần short nam là trang phục thiết yếu nhất của phái nam bởi sự tiện dụng, năng động và khỏe khoắn.\r\nThiết kế tạo điểm nhấn với nắp túi nổi bật, phá cách.\r\nMàu sắc trang nhã dễ dàng kết hợp với áo sơ mi hay áo phông rộng tôn cá tính và phong cách nổi bật cho bạn trai.\r\nChất liệu: Kaki\r\nSize: 28 - 29 - 30 - 31 - 32.', '2', 'img/Quan-Short-Kaki-Nam-Phoi-Nap-Tui-Thoi-Trang.jpg', '210000', 1471428888, 2, '200000', 1000),
(9, 'Áo Thun Nữ In Chữ Cá Tính - NT38', 'Áo thun nữ kiểu dáng thời trang, in chữ độc đáo, nổi bật tôn vẻ trẻ trung, năng động cho bạn nữ.\r\nÁo thun nữ kiểu dáng thời trang, Form rộng cá tính, in chữ nổi bật, phá cách.\r\nThiết kế năng động, màu sắc trang nhã, dễ dàng mix cùng các kiểu quần ôm, short,.. cho bạn phong cách trẻ trung, cá tính.\r\nKiểu dáng đẹp, đường chỉ may khỏe khoắn, tinh tế cho bạn phong cách hoàn hảo.\r\nChất liệu: Thun mềm mại, có độ co dãn.\r\nPhù hợp với bạn dưới 53kg (tùy chiều cao).\r\nGiao ngẫu nhiên.', '5', 'img/Ao-Thun-Nu-In-Chu-Ca-Tinh---NT38.Jpg', '135000', 1471428728, 1, '125000', 300),
(10, 'Áo Thun Nữ Tay Dài Phối Sọc Cá Tính', 'Áo thun nữ thu đông thiết kế cổ tròn, tay dài cùng họa tiết kẻ sọc trẻ trung, nổi bật cho bạn vẻ ngoài tự tin, nổi bật.\r\nForm áo đẹp, ôm nhẹ giúp tôn dáng, màu sắc trẻ trung, nổi bật.\r\nThiết kế cổ tròn, tay dài kết hợp họa tiết sọc ngang trẻ trung, ấn tượng.\r\nDễ dàng mix cùng các kiểu chân váy, quần ôm như: âu, jeans.\r\nĐường chỉ may chắc chắn, khỏe khoắn.\r\nChất liệu: Thun + demin.\r\nPhù hợp với bạn dưới 53kg (tùy chiều cao).', '5', 'img/Ao-Thun-Nu-Tay-Dai-Phoi-Soc-Ca-Tinh.jpg', '125000', 1471428808, 1, '115000', 500),
(11, 'Áo Sơ Mi Trắng Form Dài Thời Trang', 'Áo form dài năng động tạo phong cách trẻ trung, cá tính và đầy thu hút cho bạn nữ.\r\nKiểu dáng form dài, cổ bẻ, tay dài thanh lịch, form dáng chuẩn, thích hợp với nhiều vóc dáng.\r\nBạn có thể kết hợp cùng quần tây ống suông, jeans ôm hay short ngắn cùng một đôi giày cao gót bít mũi màu đen để có được vẻ năng động và chuyên nghiệp.\r\nChất liệu: kate thoáng mát.\r\nSize: M, L.\r\nMàu sắc: Trắng', '4', 'img/Ao-So-Mi-Trang-Form-Dai-Thoi-Trang.jpg', '195000', 1471428194, 1, '185000', 450),
(12, 'Áo Sơ Mi Nữ Phối Ren Bi Thời Trang', 'Áo sơ mi nữ thiết kế phối ren trẻ trung, phá cách mang đến vẻ dịu dàng, duyên dáng cho bạn nữ.\r\nÁo sơ mi nữ thiết kế cách tân với cổ tròn, tay lỡ phối ren bi đẹp mắt, ấn tượng.\r\nKiểu dáng đẹp, thắt nơ ấn tương tôn nét dễ thương, xinh xắn cho bạn nữ.\r\nThích hợp mặc đi chơi, đi làm,...\r\nChất liệu: Tơ nhung + ren bi.\r\nThích hợp với bạn gái dưới 53Kg (tùy chiều cao).\r\nMàu sắc: Đỏ Cam, Hồng Dâu, Trắng.', '4', 'img/Ao-So-Mi-Nu-Phoi-Ren-Bi-Thoi-Trang.jpg', '205000', 1471427874, 2, '197000', 600);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(128) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `ngaysinh` varchar(255) NOT NULL,
  `admin` int(1) NOT NULL DEFAULT '0',
  `sdt` varchar(20) NOT NULL,
  `diachi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Truncate table before insert `users`
--

TRUNCATE TABLE `users`;
--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `name`, `time`, `ngaysinh`, `admin`, `sdt`, `diachi`) VALUES
(1, 'admin', '827ccb0eea8a706c4c34a16891f84e7b', 'huypvpd01334@fpt.edu.vn', 'Phạm Văn Huy', 1448194897, '1996-02-16', 1, '0978246453', '138 Nguyễn Thị Thập ĐN'),
(4, 'huynam', '827ccb0eea8a706c4c34a16891f84e7b', 'huyad1102@gmail.com', 'pham van huy', 1456498861, '1998-02-16', 0, '0978246453', '123 hoàn kiếm hà nội'),
(5, 'huyad', '827ccb0eea8a706c4c34a16891f84e7b', 'huyad1102@gmail.vn', 'Lisa Dorman', 1456992080, '2000-03-03', 0, '0123458788', '548 Hà Tây'),
(6, 'test', '827ccb0eea8a706c4c34a16891f84e7b', 'test@gmail.com', 'test', 1471429735, '1997-02-11', 0, '0123487995', '22 Nguyễn Trãi, Tây Hồ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chuyenmuc`
--
ALTER TABLE `chuyenmuc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hoadon`
--
ALTER TABLE `hoadon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hoadon_chitiet`
--
ALTER TABLE `hoadon_chitiet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chuyenmuc`
--
ALTER TABLE `chuyenmuc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `hoadon`
--
ALTER TABLE `hoadon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `hoadon_chitiet`
--
ALTER TABLE `hoadon_chitiet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
